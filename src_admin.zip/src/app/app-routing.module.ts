import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FashionCreateComponent } from './fashion-create/fashion-create.component';
import { FashionDetailsComponent } from './fashion-details/fashion-details.component';
import { FashionEditComponent } from './fashion-edit/fashion-edit.component';
import { FashionIndexComponent } from './fashion-index/fashion-index.component';

const routes: Routes = [
  {
    path: 'fashion',
    component: FashionIndexComponent,
  },
  {
    path: 'fashionEdit/:id',
    component: FashionEditComponent,
  },
  {
    path: 'fashionDetails/:id',
    component: FashionDetailsComponent,
  },
  {
    path: 'fashionCreate',
    component: FashionCreateComponent,
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export const RoutingComponent=[]
