import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule, RoutingComponent } from './app-routing.module';
import { AppComponent } from './app.component';
import { FashionEditComponent } from './fashion-edit/fashion-edit.component';
import { FashionDetailsComponent } from './fashion-details/fashion-details.component';
import { FashionCreateComponent } from './fashion-create/fashion-create.component';
import { HttpClientModule} from '@angular/common/http';
import { FashionIndexComponent } from './fashion-index/fashion-index.component';
import { FroalaEditorModule, FroalaViewModule } from 'angular-froala-wysiwyg';
@NgModule({
  declarations: [
    AppComponent,
    RoutingComponent,
    FashionEditComponent,
    FashionDetailsComponent,
    FashionCreateComponent,
    FashionIndexComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    FroalaEditorModule,
    FroalaEditorModule.forRoot(),
     FroalaViewModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
